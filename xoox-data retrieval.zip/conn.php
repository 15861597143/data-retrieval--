<?php
require_once("sgk.php");
$conn = new mysqli($dbhost, $dbusername, $dbpassword, $db);
if ($conn->connect_error) {
    die("error conn" . $conn->connect_error);
}
$conn->set_charset("gbk");
?>