<?php
$dbhost="localhost";
$dbusername="xooxhennaisi";
$dbpassword="xooxhennaisi";
$db="xooxhennaisi";//数据库
$sgk="sgk";// 表
?>