﻿﻿<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>数据检索系统</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.css">
<link href="assets/css/style.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/base.css">
<link rel="stylesheet" type="text/css" href="css/home.css">
<!-- 引入 jQuery 库 -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
  /* 定义胶囊按钮的基础样式 */
.temp-form-button {
  background-color: #0193B7;
  border-radius: 50px; 
  padding: 10px 30px; 
  color: #fff; 
  border: none;
  cursor: pointer;
}

.temp-form-button:hover {
  background-color: #017ea6;
}

/* 胶囊样式的搜索框 */
#keywords {
  border-radius: 50px;
  padding: 10px 20px;
  border: 1px solid #ccc;
  outline: none;
  width: 30%;
  transition: border-color 0.3s;
}

#keywords:focus {
  border-color: #66afe9;
  box-shadow: 0 0 5px rgba(102, 175, 233, 0.6);
}

/* 固定列表头 */
.table-fixed thead {
  position: sticky;
  top: 0;
  background-color: #f8f8f8;
  z-index: 1;
}

/* 纵向胶囊设置按钮 */
#settings-button {
  position: absolute;
  top: 6px;
  right: 10px; 
  text-decoration: none;
}

/* 搜索框和按钮的父容器样式 */
.search-container {
  text-align: center; /* 使内部元素居中 */
  margin-top: 20px; /* 根据需要调整顶部外边距 */
}

/* 调整提示信息的样式 */
#hint {
  text-align: center; /* 使文本居中 */
  margin-top: 10px;
  margin-bottom: 10px;
  font-size: 1.1em;
  color: #333;
}

/* 高亮显示样式 */
.highlight {
  background-color: yellow;
  font-weight: bold;
}

/* 新增的修改数据按钮样式 */
#modify-button {
  position: absolute;
  top: 6px;
  right: 120px; /* 设置与设置按钮的距离 */
  text-decoration: none;
}
</style>
<script>
$(document).ready(function() {
    // 搜索函数
    function loadData() {
        var inputVal = $("#keywords").val().trim();
        if (inputVal === "") {
            $("#hint").text("请输入关键词");
            $("#search_result").html("");
            return;
        }
        var startTime = new Date().getTime(); // 记录开始时间
        $.ajax({
            type: "GET",
            url: "search.php",
            data: { keywords: inputVal },
            dataType: "json",
            success: function(data) {
                var con = "";
                var count = 0; // 记录数据条数
                if (data.length > 0) {
                    con += "<table class='table table-bordered table-fixed'><thead><tr><th>姓名</th><th>性别</th><th>学号</th><th>电话</th><th>身份证</th><th>班级</th><th>院系</th><th>宿舍床位号</th><th>家庭住址</th><th>其他信息</th><th>备注</th></tr></thead><tbody>";
                    $.each(data, function(i, item) {
                        if (item.result == 0) {
                            con += "<tr><td colspan='10'>请输入关键词</td></tr>";
                        } else if (item.result == 1) {
                            con += "<tr><td colspan='10'>无结果</td></tr>";
                        } else {
                            // 高亮显示匹配的关键字
                            $.each(item, function(key, value) {
                                if (typeof value === "string") {
                                    var regex = new RegExp("(" + escapeRegExp(inputVal) + ")", "gi");
                                    item[key] = value.replace(regex, "<span class='highlight'>\$1</span>");
                                }
                            });
                            con += "<tr>";
                            con += "<td>" + (item.姓名 || "") + "</td>";
                            con += "<td>" + (item.性别 || "") + "</td>";
                            con += "<td>" + (item.学号 || "") + "</td>";
                            con += "<td>" + (item.电话 || "") + "</td>";
                            con += "<td>" + (item.身份证 || "") + "</td>";
                            con += "<td>" + (item.班级 || "") + "</td>";
                            con += "<td>" + (item.院系 || "") + "</td>";
                            con += "<td>" + (item.宿舍床位号 || "") + "</td>";
                            con += "<td>" + (item.家庭住址 || "") + "</td>";
                            con += "<td>" + (item.其他信息 || "") + "</td>";
                            con += "<td>" + (item.备注 || "") + "</td>";
                            con += "</tr>";
                            count++;
                        }
                    });
                    con += "</tbody></table>";
                } else {
                    con += "<p>无数据</p>";
                }
                var endTime = new Date().getTime(); // 记录结束时间
                var timeUsed = (endTime - startTime) / 1000; // 计算用时（秒）
                $("#hint").text("为您找到" + count + "条数据，用时" + timeUsed + "秒");
                $("#search_result").html(con);
            },
            error: function(xhr, status, error) {
                $("#hint").text("搜索失败: " + error);
                $("#search_result").html("");
            }
        });
    }

    // 按下回车键触发搜索
    $("#keywords").keypress(function(e) {
        if (e.which == 13) { // 13 是回车键的键码
            loadData();
        }
    });

    // 点击搜索按钮触发搜索
    $("button.temp-form-button").click(function() {
        loadData();
    });

    // 设置按钮点击事件
    $("#settings-button").click(function(e) {
        // 使用 window.open 打开新标签页
        window.open("upload.html", "_blank"); 
    });

    // 修改数据按钮点击事件
    $("#modify-button").click(function(e) {
        // 使用 window.open 打开新标签页
        window.open("modify.php", "_blank"); 
    });

    // 辅助函数：转义正则表达式中的特殊字符
    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
});
</script>
</head>
<body>
<div class="temp-popup-form-wrapper">
<nav class="navbar navbar-inverse temp-custom-navigation">
  <div class="container-fluid">
    <div class="navbar-header temp-custom-logo-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">数据检索系统</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right temp-custom-list-items">
        <!-- 移除设置按钮 -->
      </ul>
    </div>
    <!-- 新增的修改数据按钮 -->
    <a href="#" id="modify-button" class="temp-form-button" target="_blank">修改数据</a>
    <!-- 纵向胶囊设置按钮 -->
    <a href="#" id="settings-button" class="temp-form-button" target="_blank">导入数据</a>
  </div>
</nav>

<!-- 搜索框和按钮的居中容器 -->
<div class="search-container">
  <input type="text" id="keywords" placeholder="请输入关键词">
  <button class="temp-form-button">搜索</button>
</div>

<!-- 提示信息 -->
<div id="hint">为您找到0条相关数据，用时0.00秒</div>

<div id="search_result"></div>
<!-- 移除分页容器 -->
</div>
</body>
</html>