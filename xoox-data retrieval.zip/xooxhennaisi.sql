-- MySQL dump 10.13  Distrib 5.7.26, for Win64 (x86_64)
--
-- Host: localhost    Database: xooxhennaisi
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sgk`
--

DROP TABLE IF EXISTS `sgk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sgk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `姓名` varchar(50) DEFAULT NULL,
  `性别` varchar(10) DEFAULT NULL,
  `学号` varchar(20) DEFAULT NULL,
  `电话` varchar(15) DEFAULT NULL,
  `身份证` varchar(18) DEFAULT NULL,
  `班级` varchar(20) DEFAULT NULL,
  `院系` varchar(50) DEFAULT NULL,
  `宿舍床位号` varchar(10) DEFAULT NULL,
  `家庭住址` varchar(100) DEFAULT NULL,
  `其他信息` text,
  `备注` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sgk`
--

LOCK TABLES `sgk` WRITE;
/*!40000 ALTER TABLE `sgk` DISABLE KEYS */;
INSERT INTO `sgk` VALUES (1,'我叫01','','20200202','','440982200004056801','20计算机1班（五年制）','','','','',''),(2,'我叫02','','20200346','','440982200004056802','20计算机1班（五年制）','','','','',''),(3,'我叫03','','20200418','','440982200004056803','20计算机1班（五年制）','','','','',''),(4,'我叫04','','20200499','','440982200004056804','20计算机1班（五年制）','','','','',''),(5,'我叫05','','20200503','','440982200004056805','20计算机1班（五年制）','','','','',''),(6,'我叫06','','20200559','','440982200004056806','20计算机1班（五年制）','','','','',''),(7,'我叫07','','20200616','','440982200004056807','20计算机1班（五年制）','','','','',''),(8,'我叫08','','20200627','','440982200004056808','20计算机1班（五年制）','','','','',''),(9,'我叫09','','20200656','','440982200004056809','20计算机1班（五年制）','','','','',''),(10,'我叫10','','20200700','','440982200004056810','20计算机1班（五年制）','','','','',''),(11,'我叫11','','20200718','','440982200004056811','20计算机1班（五年制）','','','','','');
/*!40000 ALTER TABLE `sgk` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-23 16:15:01
