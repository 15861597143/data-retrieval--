<?php
header("Content-type:application/json");
$keywords = $_GET["keywords"];

require_once("sgk.php");

// 创建 mysqli 连接
$conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $db);

// 检查连接是否成功
if (!$conn) {
    die('error con:' . mysqli_connect_error());
}

// 设置字符集
mysqli_set_charset($conn, "UTF8");

$keyword = trim($keywords);
if (empty($keyword)) {
    echo "[{\"result\":\"0\"}]";
} else {
    // 构建 SQL 查询语句，使用 OR 连接多个条件
    $sql = "SELECT * FROM $sgk WHERE 
            id LIKE ? OR 
            姓名 LIKE ? OR 
            性别 LIKE ? OR 
            学号 LIKE ? OR 
            电话 LIKE ? OR 
            身份证 LIKE ? OR 
            班级 LIKE ? OR 
            院系 LIKE ? OR 
            宿舍床位号 LIKE ? OR 
            家庭住址 LIKE ? OR 
            其他信息 LIKE ? OR 
            备注 LIKE ?";

    // 预处理 SQL 语句，防止 SQL 注入
    $stmt = $conn->prepare($sql);

    $searchKeyword = '%' . $keyword . '%';
    // 绑定参数，由于有 12 个占位符，需要重复绑定 12 次
    $stmt->bind_param("ssssssssssss", 
        $searchKeyword, $searchKeyword, $searchKeyword, $searchKeyword, 
        $searchKeyword, $searchKeyword, $searchKeyword, $searchKeyword, 
        $searchKeyword, $searchKeyword, $searchKeyword, $searchKeyword
    );

    $stmt->execute();
    $result = $stmt->get_result();

    $num = $result->num_rows;
    if ($num) {
        $search_result = array();
        while ($row = $result->fetch_assoc()) {
            $search_result[] = $row;
        }
        echo json_encode($search_result);
    } else {
        echo "[{\"result\":\"1\"}]";
    }

    // 关闭语句
    $stmt->close();
}

// 关闭连接
mysqli_close($conn);
?>