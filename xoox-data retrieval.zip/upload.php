<?php
// 数据库连接信息
$dbhost = "localhost";
$dbusername = "xooxhennaisi";
$dbpassword = "xooxhennaisi";
$db = "xooxhennaisi";
$sgk = "sgk";

// 连接数据库
$mysqli = new mysqli($dbhost, $dbusername, $dbpassword, $db);
if ($mysqli->connect_error) {
    die("连接失败: " . $mysqli->connect_error);
}

// 检查文件是否已上传
if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
    $file = $_FILES['file']['tmp_name'];
    $fileName = $_FILES['file']['name'];
    $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);

    echo "文件上传成功: $fileName<br>";

    // 根据文件类型解析数据
    if ($fileExt == 'xlsx') {
        // 使用PHPExcel库解析.xlsx文件
        require 'vendor/autoload.php';
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader('Xlsx');
        $spreadsheet = $reader->load($file);
        $sheetData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
    } elseif ($fileExt == 'txt' || $fileExt == 'vgs') {
        // 解析.txt或.vgs文件
        $sheetData = array_map('str_getcsv', file($file));
    } else {
        die("不支持的文件类型");
    }

    // 调试输出表头
    echo "表头: " . implode(', ', $sheetData[1]) . "<br>";

    // 获取表头映射
    $headers = $sheetData[1];
    $fieldMap = [
        '院系' => '院系',
        '性别' => '性别',
        '班级' => '班级',
        '学号' => '学号',
        '姓名' => '姓名',
        '备注' => '备注',
        '其他信息' => '其他信息',
        '身份证' => '身份证',
        '电话' => '电话',
        '宿舍床位号' => '宿舍床位号',
        '家庭住址' => '家庭住址'
    ];

    // 遍历数据行
    for ($i = 2; $i <= count($sheetData); $i++) {
        $rowData = $sheetData[$i];
        echo "处理第 $i 行数据: " . implode(', ', $rowData) . "<br>"; // 调试输出当前行数据

        $data = [];
        foreach ($fieldMap as $header => $field) {
            $data[$field] = $rowData[array_search($header, $headers)] ?? null;
        }

        // 检查记录是否存在
        $studentId = $data['学号'];
        $query = "SELECT * FROM $sgk WHERE 学号='$studentId'";
        $result = $mysqli->query($query);

        if ($result->num_rows > 0) {
            // 记录存在，对比数据
            $row = $result->fetch_assoc();
            $updateFields = [];
            foreach ($data as $key => $value) {
                if ($row[$key] == '' && $value != '') {
                    $updateFields[$key] = $value;
                }
            }

            if (!empty($updateFields)) {
                // 自动更新数据
                $updateQuery = "UPDATE $sgk SET ";
                foreach ($updateFields as $key => $value) {
                    $updateQuery .= "$key='$value', ";
                }
                $updateQuery = rtrim($updateQuery, ', ') . " WHERE 学号='$studentId'";
                if ($mysqli->query($updateQuery)) {
                    echo "数据自动更新成功<br>";
                } else {
                    echo "数据自动更新失败: " . $mysqli->error . "<br>";
                }
            } else {
                // 没有需要更新的字段，直接跳过
                echo "没有需要更新的字段，跳过该条数据<br>";
                continue;
            }
        } else {
            // 记录不存在，插入新记录
            $insertQuery = "INSERT INTO $sgk (";
            $insertQuery .= implode(', ', array_keys($data)) . ") VALUES ('";
            $insertQuery .= implode("', '", array_values($data)) . "')";
            if ($mysqli->query($insertQuery)) {
                echo "新记录插入成功<br>";
            } else {
                echo "新记录插入失败: " . $mysqli->error . "<br>";
            }
        }
    }
} else {
    echo "文件上传失败: " . $_FILES['file']['error'] . "<br>";
}

// 关闭数据库连接
$mysqli->close();
?>
