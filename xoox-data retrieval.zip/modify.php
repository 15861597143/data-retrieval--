<?php
// 数据库连接信息
$dbhost = "localhost";
$dbusername = "xooxhennaisi";
$dbpassword = "xooxhennaisi";
$dbname = "xooxhennaisi";

// 创建连接
$conn = new mysqli($dbhost, $dbusername, $dbpassword, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 初始化变量
$id = "";
$name = "";
$gender = "";
$student_id = "";
$phone = "";
$id_card = "";
$class = "";
$department = "";
$dormitory = "";
$address = "";
$other_info = "";
$remarks = "";
$rows = []; // 初始化为空数组

// 处理表单提交
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['save'])) {
        // 获取表单数据
        $id = intval($_POST['id']);
        $name = $conn->real_escape_string($_POST['name']);
        $gender = $conn->real_escape_string($_POST['gender']);
        $student_id = $conn->real_escape_string($_POST['student_id']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $id_card = $conn->real_escape_string($_POST['id_card']);
        $class = $conn->real_escape_string($_POST['class']);
        $department = $conn->real_escape_string($_POST['department']);
        $dormitory = $conn->real_escape_string($_POST['dormitory']);
        $address = $conn->real_escape_string($_POST['address']);
        $other_info = $conn->real_escape_string($_POST['other_info']);
        $remarks = $conn->real_escape_string($_POST['remarks']);

        // 更新数据库
        $sql = "UPDATE sgk SET 姓名='$name', 性别='$gender', 学号='$student_id', 电话='$phone', 身份证='$id_card', 班级='$class', 院系='$department', 宿舍床位号='$dormitory', 家庭住址='$address', 其他信息='$other_info', 备注='$remarks' WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "<div id='alert' class='alert alert-success text-center' role='alert'>记录更新成功</div>";
        } else {
            echo "<div id='alert' class='alert alert-danger text-center' role='alert'>Error updating record: " . $conn->error . "</div>";
        }
    } elseif (isset($_POST['search'])) {
        // 获取搜索条件
        $search_field = $conn->real_escape_string($_POST['search_field']);
        $search_value = $conn->real_escape_string($_POST['search_value']);

        // 查询数据库
        $sql = "SELECT * FROM sgk WHERE $search_field LIKE '%$search_value%'";
        $result = $conn->query($sql);

        if ($result === false) {
            // 处理查询错误
            echo "<div id='alert' class='alert alert-danger text-center' role='alert'>查询失败: " . $conn->error . "</div>";
            $rows = [];
        } else {
            $rows = $result->fetch_all(MYSQLI_ASSOC);
        }
    }
}

// 关闭连接
$conn->close();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据修改更新</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
            padding-top: 50px;
        }
        .search-form {
            max-width: 600px;
            margin: 0 auto 30px auto;
        }
        .card {
            margin-bottom: 20px;
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.8);
        }
        .card-header {
            background: #4CAF50;
            color: white;
            cursor: pointer;
            text-align: center;
        }
        .card-body {
            background: rgba(255, 255, 255, 0.9);
            text-align: center;
        }
        .btn-save {
            background: #4CAF50;
            border: none;
            color: white;
        }
        .btn-cancel {
            background: #f44336;
            border: none;
            color: white;
        }
        .btn-edit {
            background: #2196F3;
            border: none;
            color: white;
        }
        .btn-delete {
            background: #ff9800;
            border: none;
            color: white;
        }
        /* 提示消息样式 */
        .alert {
            position: fixed;
            right: 20px;
            bottom: 20px;
            z-index: 1050;
            width: auto;
            max-width: 300px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        /* 默认隐藏“没有找到匹配的记录”提示 */
        #no-records-alert {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4" style="color: #4CAF50;">数据修改更新</h1>
        <form class="search-form" method="post" action="">
            <div class="input-group mb-3">
                <select class="form-select" name="search_field" aria-label="字段选择">
                    <option value="姓名" selected>姓名</option>
                    <option value="id">ID</option>
                    <option value="性别">性别</option>
                    <option value="学号">学号</option>
                    <option value="电话">电话</option>
                    <option value="身份证">身份证</option>
                    <option value="班级">班级</option>
                    <option value="院系">院系</option>
                    <option value="宿舍床位号">宿舍床位号</option>
                    <option value="家庭住址">家庭住址</option>
                    <option value="其他信息">其他信息</option>
                    <option value="备注">备注</option>
                </select>
                <input type="text" class="form-control" name="search_value" id="search_value" placeholder="请输入关键字检索" aria-label="搜索内容">
                <button class="btn btn-primary" type="submit" name="search" id="search_button"><i class="fa fa-search"></i> 查找</button>
            </div>
        </form>

        <?php if (is_countable($rows) && count($rows) > 0): ?>
            <div class="row justify-content-center">
                <?php foreach ($rows as $row): ?>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <?= htmlspecialchars($row['姓名']) ?>
                            </div>
                            <div class="card-body">
                                <form method="post" action="">
                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                    <div class="row mb-3">
                                        <label for="name" class="col-md-3 col-form-label">姓名</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($row['姓名']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="gender" class="col-md-3 col-form-label">性别</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="gender" name="gender" value="<?= htmlspecialchars($row['性别']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="student_id" class="col-md-3 col-form-label">学号</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="student_id" name="student_id" value="<?= htmlspecialchars($row['学号']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="phone" class="col-md-3 col-form-label">电话</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($row['电话']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="id_card" class="col-md-3 col-form-label">身份证</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="id_card" name="id_card" value="<?= htmlspecialchars($row['身份证']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="class" class="col-md-3 col-form-label">班级</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="class" name="class" value="<?= htmlspecialchars($row['班级']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="department" class="col-md-3 col-form-label">院系</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="department" name="department" value="<?= htmlspecialchars($row['院系']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="dormitory" class="col-md-3 col-form-label">宿舍床位号</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="dormitory" name="dormitory" value="<?= htmlspecialchars($row['宿舍床位号']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="address" class="col-md-3 col-form-label">家庭住址</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="address" name="address" value="<?= htmlspecialchars($row['家庭住址']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="other_info" class="col-md-3 col-form-label">其他信息</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="other_info" name="other_info" value="<?= htmlspecialchars($row['其他信息']) ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="remarks" class="col-md-3 col-form-label">备注</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="remarks" name="remarks" value="<?= htmlspecialchars($row['备注']) ?>">
                                        </div>
                                    </div>
                                    <div class="d-grid gap-2">
                                        <button class="btn btn-save" type="submit" name="save"><i class="fa fa-save"></i> 保存</button>
                                        <!-- <button class="btn btn-secondary btn-cancel" type="button" onclick="window.location.reload();"><i class="fa fa-times"></i> 取消</button> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div id="no-records-alert" class="alert alert-warning text-center" role="alert">
                没有找到匹配的记录
            </div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS 和依赖项 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 自动隐藏提示消息
        setTimeout(function(){
            document.getElementById('alert').style.display = 'none';
            document.getElementById('no-records-alert').style.display = 'none';
        }, 1500);

        // 监听回车键触发搜索
        document.getElementById('search_value').addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                event.preventDefault();
                document.getElementById('search_button').click();
            }
        });

        // 输入验证
        document.getElementById('search_button').addEventListener('click', function(event) {
            var searchValue = document.getElementById('search_value').value.trim();
            if (searchValue === "") {
                event.preventDefault();
                // 显示提示消息
                var alertDiv = document.createElement('div');
                alertDiv.id = 'search-alert';
                alertDiv.className = 'alert alert-danger text-center';
                alertDiv.role = 'alert';
                alertDiv.innerText = '请输入内容再进行搜索';
                document.body.appendChild(alertDiv);

                // 定位到右下角
                alertDiv.style.position = 'fixed';
                alertDiv.style.right = '20px';
                alertDiv.style.bottom = '20px';
                alertDiv.style.zIndex = '1050';
                alertDiv.style.width = 'auto';
                alertDiv.style.maxWidth = '300px';
                alertDiv.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';

                // 自动隐藏
                setTimeout(function(){
                    alertDiv.style.display = 'none';
                }, 1500);
            }
        });
    </script>
</body>
</html>