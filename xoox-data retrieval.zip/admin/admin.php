<?php
session_start();
echo 'information:<br />';
?>